import os
import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

# Import layer arsitektur
from models.model import Base
from repositories.repository import MahasiswaRepository
from services.service import PrediksiService

# 1. Konfigurasi Halaman Web
st.set_page_config(
    page_title="SIAKAD - Prediksi Kelulusan",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 2. Inisialisasi Database
@st.cache_resource
def inisialisasi_database():
    load_dotenv()
    db_url = os.getenv("DATABASE_URL", "sqlite:///data_prediksi.db")
    engine = create_engine(db_url)
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    return Session()

# Dependency Injection
db_session = inisialisasi_database()
repo = MahasiswaRepository(db_session)
service = PrediksiService()

# 3. Custom CSS untuk Styling Elegan & Warna Biru Navy
st.markdown("""
    <style>
    /* Styling Sidebar */
    [data-testid="stSidebar"] {
        background-color: #0a192f;
        color: white;
    }
    [data-testid="stSidebar"] * {
        color: white !important;
    }
    .sidebar-title {
        font-size: 1.1rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        padding: 10px 0;
    }

    /* Custom Header / Top Bar */
    .top-bar {
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 12px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .top-left {
        font-size: 1.05rem;
        font-weight: 600;
        color: #334155;
    }
    .top-right {
        font-size: 0.95rem;
        color: #475569;
        font-weight: 500;
    }

    /* Card Form Styling */
    .card-container {
        background-color: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 30px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px;
    }
    .card-title {
        text-align: center;
        font-size: 1.3rem;
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 20px;
        padding: 10px;
        background-color: #f1f5f9;
        border-radius: 8px;
        border: 1px solid #cbd5e1;
    }

    /* Primary Button Custom Styling (Biru Navy) */
    div.stButton > button {
        width: 100%;
        background-color: #0a192f !important;
        color: white !important;
        font-weight: 600 !important;
        font-size: 1rem !important;
        padding: 12px 24px !important;
        border-radius: 8px !important;
        border: none !important;
        transition: all 0.3s ease;
        box-shadow: 0 4px 6px -1px rgba(10, 25, 47, 0.3);
    }
    div.stButton > button:hover {
        background-color: #1e293b !important;
        box-shadow: 0 6px 12px -2px rgba(30, 41, 59, 0.4);
    }
    </style>
""", unsafe_allow_html=True)

# 4. Sidebar Navigasi
with st.sidebar:
    st.markdown('<div class="sidebar-title">SIAKAD NAMA UNIVERSITAS</div>', unsafe_allow_html=True)
    st.divider()
    st.write("**Form Input Data Prediksi**")

# 5. Header / Top Bar
st.markdown("""
    <div class="top-bar">
        <div class="top-left">Dashboard</div>
        <div class="top-right">&nbsp;|&nbsp; 👤 Nama Lengkap Mahasiswa</div>
    </div>
""", unsafe_allow_html=True)

# 6. Card Dashboard & Form
col1, col2, col3 = st.columns([1, 8, 1])

with col2:
    st.markdown('<div class="card-title">Sistem Prediksi Kelulusan Mahasiswa</div>', unsafe_allow_html=True)
    
    with st.form("form_prediksi", clear_on_submit=False):
        nama = st.text_input("Nama Mahasiswa", placeholder="[ Masukkan nama lengkap ]")
        ipk = st.number_input("IPK (0.0 - 4.0)", min_value=0.0, max_value=4.0, step=0.01, value=0.0, help="Contoh e.g. 3.75")
        sks = st.number_input("Total SKS", min_value=0, step=1, value=0, help="Contoh e.g. 145")
        
        st.markdown("<br>", unsafe_allow_html=True)
        tombol_submit = st.form_submit_button("Prediksi & Simpan Data ➔")

    # Logika Pemrosesan Form
    if tombol_submit:
        if not nama.strip():
            st.warning("⚠️ Silakan masukkan nama mahasiswa terlebih dahulu!")
        else:
            hasil_status = service.tentukan_kelulusan(ipk, sks)
            repo.simpan_data(nama, ipk, sks, hasil_status)

            st.success("Sukses! Prediksi Mahasiswa berhasil disimpan.")
            st.rerun()

# 7. Tabel Riwayat Prediksi dengan Tanggal Input & Aksi
st.divider()
st.subheader("Riwayat Prediksi")
data_db = repo.ambil_semua_data()

if data_db:
    list_data = []
    for idx, d in enumerate(data_db, 1):
        # Ambil tanggal input jika tersedia, jika tidak gunakan tanggal default hari ini
        tgl_str = d.tanggal_input.strftime("%Y-%m-%d") if getattr(d, 'tanggal_input', None) else "2026-10-31"
        list_data.append({
            "No": idx,
            "Nama Mahasiswa": d.nama,
            "IPK": f"{d.ipk:.2f}",
            "Total SKS": d.sks,
            "Status Kelulusan": d.status_kelulusan,
            "Tanggal Input": tgl_str,
            "Aksi": "Detail"
        })
    
    df = pd.DataFrame(list_data)
    
    # Tampilkan Tabel Utama
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )

    # Panel Interaksi Aksi (Detail & Hapus Data)
    with st.expander("Detail & Aksi Data Mahasiswa"):
        pilihan_id = st.selectbox(
            "Pilih Mahasiswa:",
            options=[d.id for d in data_db],
            format_func=lambda x: f"No ID {x} - {next(d.nama for d in data_db if d.id == x)}"
        )
        
        detail_mhs = next(d for d in data_db if d.id == pilihan_id)
        tgl_detail = detail_mhs.tanggal_input.strftime("%Y-%m-%d %H:%M:%S") if getattr(detail_mhs, 'tanggal_input', None) else "2026-10-31"
        
        c1, c2 = st.columns(2)
        with c1:
            st.write(f"**Nama:** {detail_mhs.nama}")
            st.write(f"**IPK:** {detail_mhs.ipk:.2f}")
            st.write(f"**Total SKS:** {detail_mhs.sks}")
        with c2:
            st.write(f"**Status Kelulusan:** {detail_mhs.status_kelulusan}")
            st.write(f"**Waktu Input:** {tgl_detail}")
            
        if st.button("Hapus Data Ini", key=f"btn_del_{pilihan_id}"):
            repo.hapus_data(pilihan_id)
            st.success("Data berhasil dihapus!")
            st.rerun()
else:
    st.info("Belum ada data riwayat yang tersimpan.")