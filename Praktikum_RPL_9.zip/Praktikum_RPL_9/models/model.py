from sqlalchemy import Column, Integer, String, Float
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Mahasiswa(Base):
    __tablename__ = "mahasiswa"

    id = Column(Integer, primary_key=True, index=True)
    nama = Column(String, nullable=False)
    ipk = Column(Float, nullable=False)
    sks = Column(Integer, nullable=False)
    status_kelulusan = Column(String, nullable=False)

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Mahasiswa(Base):
    __tablename__ = "mahasiswa"

    id = Column(Integer, primary_key=True, index=True)
    nama = Column(String, nullable=False)
    ipk = Column(Float, nullable=False)
    sks = Column(Integer, nullable=False)
    status_kelulusan = Column(String, nullable=False)
    tanggal_input = Column(DateTime, default=datetime.now)  # Menambahkan kolom tanggal